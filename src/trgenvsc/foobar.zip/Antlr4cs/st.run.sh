./bin/Debug/net7.0/<if(os_win)>Test.exe<else>Test<endif> "$@"
