﻿namespace Server
{
    public class QuickInfo
    {
        public string Display;
        public Workspaces.Range Range;
    }
}
