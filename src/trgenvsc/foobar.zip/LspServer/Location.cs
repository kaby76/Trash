﻿namespace Server
{
    using Workspaces;

    public class Location
    {
        public Document Uri;
        public Range Range;
    }
}
