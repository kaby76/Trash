﻿namespace Server
{
    public class TextEdit
    {
        public Workspaces.Range range;
        public string NewText;
    }
}
