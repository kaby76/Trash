python3 Test.py "$@"
