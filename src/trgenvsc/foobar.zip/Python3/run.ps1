python3 Test.py $args
