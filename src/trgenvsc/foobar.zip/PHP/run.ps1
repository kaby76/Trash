php -d memory_limit=1G Test.php $args
