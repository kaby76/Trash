./build/<if(os_win)>Release/<endif><exec_name> "$@"
