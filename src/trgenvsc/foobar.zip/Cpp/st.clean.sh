# Generated from trgen <version>
rm -rf build <temp_dir>/antlr4_runtime
