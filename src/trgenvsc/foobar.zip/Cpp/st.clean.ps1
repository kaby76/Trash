# Generated from trgen <version>
$(& Remove-Item build -Recurse -Force ) 2>&1 | Out-Null
$(& Remove-Item <temp_dir>/antlr4_runtime -Recurse -Force ) 2>&1 | Out-Null
exit 0
