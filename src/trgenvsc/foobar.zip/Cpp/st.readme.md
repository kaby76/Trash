# Instructions to build and run:

## Windows -- Msys2 64-bit

    cd Generated
    mkdir build
    cd build
    cmake .. -G "MinGW Makefiles"
    make
    cat input-file | Text.exe

