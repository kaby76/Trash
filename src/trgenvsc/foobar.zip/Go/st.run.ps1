./<if(os_win)>Test.exe<else>Test<endif> $args
