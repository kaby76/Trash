node Test.js $args
