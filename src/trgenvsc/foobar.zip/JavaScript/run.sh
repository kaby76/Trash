node Test.js "$@"
